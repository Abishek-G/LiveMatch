﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models
{
    public class Matches
    {
        public int match_id { get; set; }

        public int home_team_id { get; set; }

        public int away_team_id { get; set; }

        public DateTime? match_date { get; set; }
    }
}