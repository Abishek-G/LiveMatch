﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models
{
    public class Teams
    {
        public int id { get; set; }
        public string team_name { get; set; }
        public string team_logo { get; set; }
        public string coach { get; set;}
        public string college { get; set;}
    }
}