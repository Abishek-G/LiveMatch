﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using API.Models;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace API.Controllers
{
    public class TeamsController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();

            string query = @"select t.team_name name,t.team_logo logo, tm.total_matches played, tm.wins won,tm.loss loss,tm.draw draw,tm.goals_for,tm.goals_against,tm.points total from TournamentStandings tm
join Teams t
on t.id = tm.team_id";

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["footballDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
    }
}
