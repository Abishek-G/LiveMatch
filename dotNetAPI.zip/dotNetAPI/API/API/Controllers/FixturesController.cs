﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using API.Models;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace API.Controllers
{
    public class FixturesController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();

            string query = @"select m.match_id, t.team_name home_team,t.team_logo homelogo, at.team_name away_team,at.team_logo awaylogo, m.match_date date, s.stadium_name venue from matches m
                            join teams t
                            on t.id = m.home_team_id 
                            join teams at
                            on at.id = m.away_team_id
                            join Stadiums s
                            on s.stadium_id = m.stadium_id;";

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["footballDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
    }
}
