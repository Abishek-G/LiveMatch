﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace API.Controllers
{
    
    public class MatchesController : ApiController
    {
     
        public HttpResponseMessage Get()
        {
            
            DataTable table = new DataTable();

            string query = @"
                            select m.match_id,m.status status, t.team_name home_team,t.team_logo homelogo, at.team_name away_team,at.team_logo awaylogo,m.home_score homeScore,m.away_score awayScore, m.match_date date, r.refree_name refree, s.stadium_name venue from matches m
                            join teams t
                            on t.id = m.home_team_id 
                            join teams at
                            on at.id = m.away_team_id
                            join Refrees r 
                            on r.refree_id = m.refree_id
                            join Stadiums s
                            on s.stadium_id = m.stadium_id;"
                            ;

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["footballDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
    }
}
